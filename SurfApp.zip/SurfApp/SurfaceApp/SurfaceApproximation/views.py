from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from .functions import display_raw_data
from django.core.files.storage import FileSystemStorage
import os

def home(request):
    return render(request, 'home.html')

def start(request):
    return render(request, 'start.html')

def calculate(request):
    #take values from html to python
    model = request.POST["myModel"]
    file = request.FILES["myFile"]

    #save the file to the Media
    fs = FileSystemStorage()
    fs.save(file.name, file)
    path = "Media"+ "/" + file.name

    #show the raw data plot
    display_raw_data(path, model)

    #delete file object from Media
    filelist = [os.remove(f) for f in os.listdir(os.chdir("Media"))]

    return render(request, 'result.html')
