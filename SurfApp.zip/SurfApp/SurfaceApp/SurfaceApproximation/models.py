from django.db import models

class AppData(models.Model):
    app_model = models.TextField()
    app_file = models.TextField()