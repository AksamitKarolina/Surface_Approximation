from django.apps import AppConfig


class SurfaceapproximationConfig(AppConfig):
    name = 'SurfaceApproximation'
